Run the stand-alone distribution from the command line using:
    java -jar -Xmx256m ${standalone.jar.name}-all32.jar
